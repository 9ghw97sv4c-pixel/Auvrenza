import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  return {
    rules: [{
      userAgent: "*",
      allow: "/",
      disallow: ["/admin", "/api", "/account", "/checkout", "/cart", "/wishlist", "/login", "/register", "/forgot-password", "/reset-password"],
    }],
    sitemap: `${base}/sitemap.xml`,
  };
}
